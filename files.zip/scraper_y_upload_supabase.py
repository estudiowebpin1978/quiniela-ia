"""
════════════════════════════════════════════════════════════════
  QUINIELA NACIONAL - SCRAPER + UPLOAD A SUPABASE
  Fuente:   quinieleando.com.ar
  Destino:  Supabase → tabla public.draws
  Proyecto: quiniela ia (wazkylxgqckjfkcmfotl)

  • Solo raspa fechas que NO están en la base de datos
  • Sube registros nuevos (upsert por date+turno)
  • Loguea cada sync en public.sync_logs
  • Imprime estadísticas al final

  Requisitos:
      pip install requests beautifulsoup4

  Configuración:
      Completar SUPABASE_URL y SUPABASE_KEY antes de correr.
════════════════════════════════════════════════════════════════
"""

import requests
from bs4 import BeautifulSoup
import time
import json
from datetime import date, timedelta, datetime

# ──────────────────────────────────────────────────────────────
# ⚙️  CONFIGURACIÓN  (completar antes de ejecutar)
# ──────────────────────────────────────────────────────────────
SUPABASE_URL = "https://wazkylxgqckjfkcmfotl.supabase.co"
SUPABASE_KEY = "TU_SUPABASE_ANON_O_SERVICE_ROLE_KEY"   # ← reemplazar

DIAS_ATRAS   = 365       # cuántos días hacia atrás revisar
DELAY_SEG    = 0.9       # pausa entre requests al scraper
BATCH_SIZE   = 50        # registros por insert batch

# ──────────────────────────────────────────────────────────────
BASE_SCRAPER = "https://quinieleando.com.ar/quinielas/nacional/resultados-del-{d}-{m}-{y}"

HEADERS_SCRAPER = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    )
}

TURNOS_MAP = {
    "LA PREVIA":   "previa",
    "LA PRIMERA":  "primera",
    "MATUTINA":    "matutina",
    "VESPERTINA":  "vespertina",
    "NOCTURNA":    "nocturna",
}

# ══════════════════════════════════════════════════════════════
# SUPABASE HELPERS
# ══════════════════════════════════════════════════════════════

def sb_headers():
    return {
        "apikey":        SUPABASE_KEY,
        "Authorization": f"Bearer {SUPABASE_KEY}",
        "Content-Type":  "application/json",
        "Prefer":        "return=minimal",
    }


def sb_get_fechas_existentes() -> set[date]:
    """Devuelve el conjunto de fechas que ya tienen al menos 1 registro en draws."""
    url = f"{SUPABASE_URL}/rest/v1/draws?select=date&limit=5000"
    resp = requests.get(url, headers=sb_headers(), timeout=20)
    resp.raise_for_status()
    filas = resp.json()
    return {date.fromisoformat(f["date"]) for f in filas}


def sb_upsert_batch(registros: list[dict]) -> int:
    """
    Inserta/actualiza en draws.
    Cada registro: {date, turno, numbers, source}
    Devuelve cantidad insertada (o 0 si falla).
    """
    url = f"{SUPABASE_URL}/rest/v1/draws"
    headers = sb_headers()
    headers["Prefer"] = "resolution=merge-duplicates,return=minimal"

    resp = requests.post(url, headers=headers, json=registros, timeout=30)
    if resp.status_code in (200, 201):
        return len(registros)
    else:
        print(f"  ⚠  Supabase error {resp.status_code}: {resp.text[:200]}")
        return 0


def sb_log_sync(status: str, insertados: int, error: str = None,
                ms: int = None, metadata: dict = None):
    """Registra en sync_logs."""
    url = f"{SUPABASE_URL}/rest/v1/sync_logs"
    payload = {
        "source":            "scraper_quinieleando",
        "status":            status,
        "records_inserted":  insertados,
        "error_message":     error,
        "execution_time_ms": ms,
        "metadata":          json.dumps(metadata or {}),
    }
    try:
        requests.post(url, headers=sb_headers(), json=payload, timeout=10)
    except Exception:
        pass  # el log falla silenciosamente


# ══════════════════════════════════════════════════════════════
# SCRAPING
# ══════════════════════════════════════════════════════════════

def parsear_pagina(html: str, fecha: date) -> list[dict]:
    """
    Extrae todos los turnos del día.
    Retorna lista de dicts listos para Supabase:
      {date, turno, numbers (list[int]), source}
    """
    soup = BeautifulSoup(html, "html.parser")
    registros = []

    for tabla in soup.find_all("table"):
        th = tabla.find("th")
        if not th:
            continue
        header = th.get_text(separator=" ", strip=True).upper()

        turno_key = next((k for k in TURNOS_MAP if k in header), None)
        if not turno_key:
            continue
        turno = TURNOS_MAP[turno_key]

        # Extraer 20 números (4 dígitos cada uno)
        celdas = tabla.find_all("td")
        numeros = {}
        idx = 0

        while idx < len(celdas) and len(numeros) < 20:
            texto = celdas[idx].get_text(strip=True)
            if texto.isdigit() and 1 <= int(texto) <= 20:
                pos = int(texto)
                if idx + 1 < len(celdas):
                    val = celdas[idx + 1].get_text(strip=True)
                    if len(val) == 4 and val.isdigit():
                        numeros[pos] = int(val)
                        idx += 2
                        continue
            idx += 1

        if len(numeros) >= 15:
            numbers_arr = [numeros.get(p, 0) for p in range(1, 21)]
            registros.append({
                "date":    fecha.isoformat(),
                "turno":   turno,
                "numbers": numbers_arr,
                "source":  "scraper_quinieleando",
            })

    return registros


def raspar_fecha(fecha: date, session: requests.Session) -> list[dict]:
    url = BASE_SCRAPER.format(
        d=str(fecha.day).zfill(2),
        m=str(fecha.month).zfill(2),
        y=fecha.year
    )
    try:
        resp = session.get(url, headers=HEADERS_SCRAPER, timeout=15)
        if resp.status_code == 200:
            return parsear_pagina(resp.text, fecha)
        elif resp.status_code == 404:
            return []   # feriado / suspensión
        else:
            print(f"    HTTP {resp.status_code}")
            return []
    except requests.RequestException as e:
        print(f"    Error: {e}")
        return []


# ══════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════

def main():
    t0 = datetime.now()
    print("═" * 62)
    print("  QUINIELA NACIONAL → SUPABASE   (proyecto: quiniela ia)")
    print("═" * 62)

    if SUPABASE_KEY == "TU_SUPABASE_ANON_O_SERVICE_ROLE_KEY":
        print("\n❌  Falta configurar SUPABASE_KEY en el script.")
        return

    # 1. Fechas que ya existen en Supabase
    print("\n📡  Consultando fechas existentes en Supabase…")
    try:
        existentes = sb_get_fechas_existentes()
    except Exception as e:
        print(f"❌  No se pudo conectar a Supabase: {e}")
        return
    print(f"    → {len(existentes)} fechas ya registradas")

    # 2. Fechas a raspar (Lun-Sáb de los últimos N días, excluyendo existentes)
    hoy = date.today()
    todas = [
        hoy - timedelta(days=i)
        for i in range(DIAS_ATRAS + 1)
        if (hoy - timedelta(days=i)).weekday() != 6   # sin domingos
    ]
    faltantes = sorted(d for d in todas if d not in existentes)
    print(f"    → {len(faltantes)} fechas faltantes a raspar\n")

    if not faltantes:
        print("✅  ¡Base de datos al día! No hay fechas faltantes.")
        sb_log_sync("skipped", 0, metadata={"razon": "sin_fechas_faltantes"})
        return

    # 3. Scraping
    todos_registros = []
    session = requests.Session()
    total = len(faltantes)

    for i, fecha in enumerate(faltantes, 1):
        dia_es = ["Lun","Mar","Mié","Jue","Vie","Sáb"][fecha.weekday()]
        print(f"[{i:>3}/{total}]  {fecha}  {dia_es}", end="  →  ")

        regs = raspar_fecha(fecha, session)

        if regs:
            print(f"{len(regs)} turnos")
            todos_registros.extend(regs)
        else:
            print("sin datos (feriado o página vacía)")

        if i < total:
            time.sleep(DELAY_SEG)

    # 4. Upload en batches
    print(f"\n📤  Subiendo {len(todos_registros)} registros a Supabase…")
    total_ok = 0

    for start in range(0, len(todos_registros), BATCH_SIZE):
        batch = todos_registros[start:start + BATCH_SIZE]
        ok = sb_upsert_batch(batch)
        total_ok += ok
        print(f"    Batch {start//BATCH_SIZE + 1}: {ok}/{len(batch)} insertados")

    # 5. Log y resumen
    ms = int((datetime.now() - t0).total_seconds() * 1000)
    status = "success" if total_ok > 0 else ("skipped" if not todos_registros else "failed")
    sb_log_sync(
        status=status,
        insertados=total_ok,
        ms=ms,
        metadata={"fechas_procesadas": total, "fechas_faltantes": len(faltantes)}
    )

    print(f"\n{'═'*62}")
    print(f"  ✅  Finalizado en {ms/1000:.1f}s")
    print(f"  📊  Registros insertados:  {total_ok}")
    print(f"  📅  Fechas procesadas:     {total}")
    print(f"{'═'*62}")


if __name__ == "__main__":
    main()
