"""
════════════════════════════════════════════════════════════════
  QUINIELA NACIONAL - ANÁLISIS ESTADÍSTICO (desde Supabase)

  Consulta las vistas creadas en Supabase y genera reportes:
    1. Top cabezas (posición 1) por turno
    2. Números más frecuentes en los 20 extractos
    3. Números más atrasados (días sin salir)
    4. Cobertura de datos disponibles

  Requisitos:
      pip install requests tabulate

  Configuración:
      Completar SUPABASE_URL y SUPABASE_KEY
════════════════════════════════════════════════════════════════
"""

import requests
from tabulate import tabulate

# ──────────────────────────────────────────────────────────────
# ⚙️  CONFIGURACIÓN
# ──────────────────────────────────────────────────────────────
SUPABASE_URL = "https://wazkylxgqckjfkcmfotl.supabase.co"
SUPABASE_KEY = "TU_SUPABASE_ANON_O_SERVICE_ROLE_KEY"   # ← reemplazar
# ──────────────────────────────────────────────────────────────

TURNOS_ORDEN = ["previa", "primera", "matutina", "vespertina", "nocturna"]


def sb_get(endpoint: str, params: dict = None) -> list[dict]:
    headers = {
        "apikey":        SUPABASE_KEY,
        "Authorization": f"Bearer {SUPABASE_KEY}",
    }
    resp = requests.get(
        f"{SUPABASE_URL}/rest/v1/{endpoint}",
        headers=headers,
        params=params or {},
        timeout=20
    )
    resp.raise_for_status()
    return resp.json()


def separador(titulo: str):
    print(f"\n{'═'*62}")
    print(f"  {titulo}")
    print('═'*62)


# ══════════════════════════════════════════════════════════════
# 1. ESTADO GENERAL DE LOS DATOS
# ══════════════════════════════════════════════════════════════
def reporte_cobertura():
    separador("📅  COBERTURA DE DATOS POR TURNO")
    filas = sb_get("v_stats_por_turno", {"order": "turno.asc"})
    tabla = [
        [r["turno"].capitalize(), r["total_sorteos"], r["dias_con_datos"],
         r["desde"], r["hasta"]]
        for r in filas
    ]
    print(tabulate(tabla,
                   headers=["Turno", "Sorteos", "Días", "Desde", "Hasta"],
                   tablefmt="rounded_outline"))


# ══════════════════════════════════════════════════════════════
# 2. TOP 20 CABEZAS POR TURNO
# ══════════════════════════════════════════════════════════════
def reporte_top_cabezas():
    separador("🏆  TOP 20 TERMINACIONES MÁS FRECUENTES EN CABEZA (pos. 1)")
    for turno in TURNOS_ORDEN:
        filas = sb_get("v_frecuencia_cabeza", {
            "turno":    f"eq.{turno}",
            "order":    "apariciones.desc",
            "limit":    "20",
        })
        if not filas:
            continue
        print(f"\n  ── {turno.upper()} ──────────────────────────────")
        tabla = [
            [r["terminacion"], r["apariciones"], f"{r['pct']}%"]
            for r in filas
        ]
        print(tabulate(tabla,
                       headers=["Terminación", "Veces", "% del turno"],
                       tablefmt="simple",
                       colalign=("center", "right", "right")))


# ══════════════════════════════════════════════════════════════
# 3. TOP 20 FRECUENTES EN CUALQUIER POSICIÓN
# ══════════════════════════════════════════════════════════════
def reporte_frecuencia_general():
    separador("📊  TOP 20 TERMINACIONES EN CUALQUIER POSICIÓN (1-20)")
    for turno in TURNOS_ORDEN:
        filas = sb_get("v_frecuencia_general", {
            "turno":  f"eq.{turno}",
            "order":  "apariciones.desc",
            "limit":  "20",
        })
        if not filas:
            continue
        print(f"\n  ── {turno.upper()} ──────────────────────────────")
        tabla = [
            [r["terminacion"], r["apariciones"]]
            for r in filas
        ]
        print(tabulate(tabla,
                       headers=["Terminación", "Apariciones"],
                       tablefmt="simple",
                       colalign=("center", "right")))


# ══════════════════════════════════════════════════════════════
# 4. NÚMEROS MÁS ATRASADOS
# ══════════════════════════════════════════════════════════════
def reporte_atrasados(top_n: int = 15):
    separador(f"⏳  TOP {top_n} NÚMEROS MÁS ATRASADOS EN CABEZA")
    for turno in TURNOS_ORDEN:
        filas = sb_get("v_numeros_atrasados", {
            "turno":  f"eq.{turno}",
            "order":  "dias_atrasado.desc",
            "limit":  str(top_n),
        })
        if not filas:
            continue
        print(f"\n  ── {turno.upper()} ──────────────────────────────")
        tabla = [
            [r["terminacion"], r["ultima_fecha"], r["dias_atrasado"]]
            for r in filas
        ]
        print(tabulate(tabla,
                       headers=["Terminación", "Última salida", "Días atrás"],
                       tablefmt="simple",
                       colalign=("center", "left", "right")))


# ══════════════════════════════════════════════════════════════
# 5. DÍAS FALTANTES EN LA BD
# ══════════════════════════════════════════════════════════════
def reporte_faltantes():
    from datetime import date, timedelta
    separador("🔍  FECHAS FALTANTES (sin sorteos en la BD)")

    filas = sb_get("v_cobertura_diaria", {
        "order": "date.asc",
        "limit": "2000",
    })
    presentes = {r["date"] for r in filas}
    hoy = date.today()
    faltantes = []

    for i in range(365):
        d = hoy - timedelta(days=i)
        if d.weekday() == 6:  # domingo
            continue
        if d.isoformat() not in presentes:
            faltantes.append(d)

    faltantes.sort()
    if not faltantes:
        print("\n  ✅  ¡Sin fechas faltantes! Base de datos completa.")
    else:
        print(f"\n  ⚠   {len(faltantes)} fechas laborables sin datos:\n")
        for d in faltantes:
            dia = ["Lun","Mar","Mié","Jue","Vie","Sáb"][d.weekday()]
            print(f"    {d}  ({dia})")


# ══════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════
def main():
    if SUPABASE_KEY == "TU_SUPABASE_ANON_O_SERVICE_ROLE_KEY":
        print("❌  Configurar SUPABASE_KEY antes de ejecutar.")
        return

    print("\n🎰  ANÁLISIS ESTADÍSTICO - QUINIELA NACIONAL")
    print("    Fuente: Supabase (proyecto: quiniela ia)\n")

    reporte_cobertura()
    reporte_top_cabezas()
    reporte_frecuencia_general()
    reporte_atrasados()
    reporte_faltantes()

    print(f"\n{'═'*62}")
    print("  ✅  Análisis completado.")
    print(f"{'═'*62}\n")


if __name__ == "__main__":
    main()
